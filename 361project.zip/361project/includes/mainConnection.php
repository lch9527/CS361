
<?php
/*$servername = "localhost";
$username = "root";
$password = "2020";
$dbname = "swapbook";

// Create connection
$mainConnection = new mysqli($servername, $username, $password);

// Check connection
if ($mainConnection->connect_error) {
    die("Connection failed: " . $mainConnection->connect_error);
}
echo "<!-- Connected successfully -->"; */
?>